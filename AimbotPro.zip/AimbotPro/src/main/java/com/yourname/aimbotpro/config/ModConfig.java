package com.yourname.aimbotpro.config;

import me.shedaniel.autoconfig.ConfigData;
import me.shedaniel.autoconfig.annotation.Config;
import me.shedaniel.autoconfig.annotation.ConfigEntry;

@Config(name = "aimbotpro")
public class ModConfig implements ConfigData {

    // ===== BẬT/TẮT TỔNG =====
    @ConfigEntry.Gui.Tooltip
    public boolean enableAimbot = true;

    // ===== TẦM AIM (1 - 6 blocks) =====
    @ConfigEntry.Gui.Tooltip
    @ConfigEntry.BoundedDiscrete(min = 1, max = 6)
    public int reachDistance = 4;

    // ===== TỐC ĐỘ AIM (1 - 10) =====
    @ConfigEntry.Gui.Tooltip
    @ConfigEntry.BoundedDiscrete(min = 1, max = 10)
    public int aimSpeed = 8;

    // ===== FOV (10 - 360 độ) =====
    @ConfigEntry.Gui.Tooltip
    @ConfigEntry.BoundedDiscrete(min = 10, max = 360)
    public int fov = 120;

    // ===== CHẾ ĐỘ AIM: HEAD / MID / LEG =====
    @ConfigEntry.Gui.Tooltip
    public AimPosition aimPosition = AimPosition.HEAD;

    // ===== FILTERS =====
    @ConfigEntry.Gui.Tooltip
    public boolean targetPlayers = true;

    @ConfigEntry.Gui.Tooltip
    public boolean targetMobs = true;

    @ConfigEntry.Gui.Tooltip
    public boolean targetInvisible = false;

    public enum AimPosition {
        HEAD,
        MID,
        LEG
    }
}
package com.yourname.aimbotpro.util;

import com.yourname.aimbotpro.config.ConfigManager;
import com.yourname.aimbotpro.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3d;

import java.util.List;
import java.util.Comparator;

public class AimCalculator {

    private static LivingEntity currentTarget = null;

    /**
     * Xử lý aim chính, gọi mỗi tick từ ClientTickEvents.END_CLIENT_TICK
     */
    public static void processAim(MinecraftClient client) {
        var config = ConfigManager.getConfig();
        var player = client.player;
        var world = client.world;
        if (player == null || world == null) return;

        // 1. Quét các thực thể trong bán kính
        double reach = config.reachDistance;
        Box searchBox = player.getBoundingBox().expand(reach);
        List<LivingEntity> entities = world.getEntitiesByClass(
                LivingEntity.class,
                searchBox,
                e -> e != player && EntityFilter.isValidTarget(e)
        );

        if (entities.isEmpty()) {
            currentTarget = null;
            return;
        }

        // 2. Chọn mục tiêu gần tâm ngắm nhất (dựa trên góc FOV)
        Vec3d eyePos = player.getEyePos();
        Vec3d lookVec = player.getRotationVec(1.0F);

        LivingEntity bestTarget = null;
        double bestAngle = Double.MAX_VALUE;

        for (LivingEntity entity : entities) {
            // Lấy vị trí aim dựa trên chế độ
            Vec3d targetPos = getAimPosition(entity, config.aimPosition);

            // Vector từ mắt người chơi đến target
            Vec3d toTarget = targetPos.subtract(eyePos);
            double distance = toTarget.length();
            if (distance > reach) continue;

            // Tính góc lệch so với hướng nhìn
            Vec3d toTargetNorm = toTarget.normalize();
            double angle = Math.acos(MathHelper.clamp(lookVec.dotProduct(toTargetNorm), -1.0, 1.0));
            double angleDeg = Math.toDegrees(angle);

            // Kiểm tra FOV
            if (angleDeg > config.fov) continue;

            // Chọn mục tiêu có góc nhỏ nhất (gần tâm ngắm nhất)
            if (angleDeg < bestAngle) {
                bestAngle = angleDeg;
                bestTarget = entity;
            }
        }

        if (bestTarget == null) {
            currentTarget = null;
            return;
        }

        currentTarget = bestTarget;

        // 3. ANTI-JITTER: Raycast kiểm tra xem tâm đã nằm trong hitbox chưa
        HitResult hit = client.crosshairTarget;
        if (hit instanceof EntityHitResult entityHit) {
            if (entityHit.getEntity() == currentTarget) {
                // Tâm đã nằm trong hitbox → không làm gì, tránh giật
                return;
            }
        }

        // 4. Tính toán góc cần xoay
        Vec3d targetPos = getAimPosition(currentTarget, config.aimPosition);
        Vec3d delta = targetPos.subtract(eyePos);

        float targetYaw = (float) Math.toDegrees(Math.atan2(-delta.x, delta.z));
        float targetPitch = (float) Math.toDegrees(Math.atan2(-delta.y, Math.sqrt(delta.x * delta.x + delta.z * delta.z)));

        // Chuẩn hoá góc
        targetYaw = MathHelper.wrapDegrees(targetYaw);
        targetPitch = MathHelper.clamp(targetPitch, -90, 90);

        float currentYaw = player.getYaw();
        float currentPitch = player.getPitch();

        // 5. Nội suy theo tốc độ (1-10)
        float speed = config.aimSpeed / 10.0F; // 0.1 -> 1.0
        if (speed >= 1.0F) {
            // Snap ngay lập tức
            player.setYaw(targetYaw);
            player.setPitch(targetPitch);
        } else {
            // Nội suy tuyến tính có wrap cho yaw
            float yawDiff = MathHelper.wrapDegrees(targetYaw - currentYaw);
            float pitchDiff = targetPitch - currentPitch;

            float newYaw = currentYaw + yawDiff * speed;
            float newPitch = currentPitch + pitchDiff * speed;

            player.setYaw(newYaw);
            player.setPitch(newPitch);
        }
    }

    /**
     * Lấy vị trí aim trên entity dựa trên chế độ HEAD/MID/LEG
     */
    private static Vec3d getAimPosition(LivingEntity entity, ModConfig.AimPosition pos) {
        return switch (pos) {
            case HEAD -> entity.getEyePos();
            case MID -> entity.getPos().add(0, entity.getHeight() / 2, 0);
            case LEG -> entity.getPos().add(0, 0.1, 0);
        };
    }

    public static LivingEntity getCurrentTarget() {
        return currentTarget;
    }
}
package com.yourname.aimbotpro.util;

import com.yourname.aimbotpro.config.ConfigManager;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;

public class EntityFilter {

    public static boolean isValidTarget(LivingEntity target) {
        if (target == null) return false;

        var config = ConfigManager.getConfig();

        // Bỏ qua chính bản thân
        if (target.isMainPlayer()) return false;

        // Filter người chơi
        if (target instanceof PlayerEntity) {
            if (!config.targetPlayers) return false;
            // Bỏ qua người chơi chế độ sáng tạo / giám sát (tuỳ chọn)
        }

        // Filter quái vật (Hostile)
        if (target instanceof MobEntity) {
            if (!config.targetMobs) return false;
        }

        // Filter tàng hình
        if (target.isInvisible()) {
            if (!config.targetInvisible) return false;
        }

        // Bỏ qua thực thể chết
        if (target.isDead()) return false;

        return true;
    }
}
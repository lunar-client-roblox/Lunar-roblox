package com.yourname.aimbotpro;

import com.yourname.aimbotpro.config.ConfigManager;
import com.yourname.aimbotpro.util.AimCalculator;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public class AimbotProClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        // Tải config
        ConfigManager.load();

        // Đăng ký tick event xử lý aim
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (!ConfigManager.getConfig().enableAimbot) return;

            AimCalculator.processAim(client);
        });

        System.out.println("[AimbotPro] Initialized successfully.");
    }
}
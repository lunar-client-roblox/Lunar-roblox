package com.yourname.aimbotpro.mixin;

import com.yourname.aimbotpro.util.AimCalculator;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin vào ClientPlayerEntity để đồng bộ góc nhìn lên server
 * (đảm bảo góc nhìn đã thay đổi được gửi đi)
 */
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        // Không cần logic thêm, chỉ để đảm bảo mixin được load
        // Góc nhìn đã được set trực tiếp trong AimCalculator
    }
}